library(testthat)
library(htmltools)

test_package("htmltools")
